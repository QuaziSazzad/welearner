<?php
/**
 * @package welearner-core
 * @version 1.0.0
 */
/*
Plugin Name: Welearner Core
Plugin URI:
Description: This is a helper plugin for Welearner theme
Author: quazi sazzad
Version: 1.0.0
*/

if(!defined('ABSPATH')){
  exit;
}


/** Plugin version **/
define('WELERNER_CORE_VERSION','1.0.0');

/*
 * Define Plugin Dir Path
 * @since 1.0.0
 * */


define('WELERNER_CORE_NAME','WELERNER_CORE');
define('WELERNER_CORE_ROOT_PATH', plugin_dir_path(__FILE__));
define('WELERNER_CORE_ROOT_URL', plugin_dir_url(__FILE__));
define('WELERNER_CORE_ADMIN', WELERNER_CORE_ROOT_PATH.'/admin');
define('WELERNER_CORE_INC', WELERNER_CORE_ROOT_PATH .'/inc');
define('WELERNER_CORE_CSS', WELERNER_CORE_ROOT_URL .'assets/css');
define('WELERNER_CORE_IMG', WELERNER_CORE_ROOT_URL .'assets/img');
define('WELERNER_CORE_JS', WELERNER_CORE_ROOT_URL .'assets/js');



//plugin core file include
if ( file_exists( WELERNER_CORE_INC .'/class-welearner-init.php') ){
	require_once WELERNER_CORE_INC .'/class-welearner-init.php';
}

//add image size

add_image_size( 'welearner-course', 308,162,true );
add_image_size( 'welearner-testimonial', 70,70,true );
add_image_size( 'welearner-team', 350,356,true );
add_image_size( 'welearner-blog', 350,214,true );
