<?php
/**
 * @package MbpCore
 * @sicne 1.0.0
 * */

if (!class_exists('Welearner_Init')){

	class Welearner_Init{

	//instance
	protected static $instance;

	public function __construct() {		
		//load plugin dependency files
		self::load_plugin_dependency_files();
	}

	/**
	 * getInstance()
	 * @since 1.0.0
	 * */
	public static function getInstance(){
		if (null == self::$instance){
			self::$instance = new self();
		}
		return self::$instance;
	}

	

	/**
	 * load_plugin_dependency_files()
	 * @since 1.0.0
	 * */
	public function load_plugin_dependency_files(){

		$includes_files = array(
				array(
					'file-name' => 'class-welearner-cpt',
					'file-path' => WELERNER_CORE_ADMIN
				),
				array(
					'file-name' => 'welearner_course_meta',
					'file-path' => WELERNER_CORE_ADMIN
				),
				array(
					'file-name' => 'welearner_team_meta',
					'file-path' => WELERNER_CORE_ADMIN
				),
				array(
					'file-name' => 'welearner_testimonial_meta',
					'file-path' => WELERNER_CORE_ADMIN
				),
				array(
					'file-name' => 'welearner_counter_meta',
					'file-path' => WELERNER_CORE_ADMIN
				),
				array(
					'file-name' => 'class-welearner-taxonomy',
					'file-path' => WELERNER_CORE_ADMIN
				),
				array(
					'file-name' => 'taxonomy-meta',
					'file-path' => WELERNER_CORE_ADMIN
				),
				array(
					'file-name' => 'demo-import',
					'file-path' => WELERNER_CORE_INC
				),
			);
		if (is_array($includes_files) && !empty($includes_files)){
				foreach ($includes_files as  $file){
					if (file_exists( $file['file-path'].'/'. $file['file-name'].'.php')){
						require_once $file['file-path'].'/'. $file['file-name'].'.php';
					}
				}
			}
	
	}

	}//end class
}

if ( class_exists('Welearner_Init')){
	Welearner_Init::getInstance();
}

