<?php 
/*
* @since 1.0.0
 */
function weleaner_core_import() { 
  return array(
    array(
      'import_file_name'             => __('Demo','welearner-core'),
      'page_title'                   => __('Insert Demo','welearner-core'),
      'local_import_customizer_file' =>  WELERNER_CORE_ROOT_PATH.'/demo/customiser.dat',
      'local_import_file'            => WELERNER_CORE_ROOT_PATH.'/demo/demo-data.xml',
      'local_import_widget_file'     => WELERNER_CORE_ROOT_PATH.'/demo/widget.wie',
      ),
      'import_notice'                => __( 'This import maybe finish on 5-10 minutes', 'welearner-core' ),
   
);
}
add_filter( 'pt-ocdi/import_files', 'weleaner_core_import' );

add_action( 'pt-ocdi/after_import',  'welearner_after_import' );
if(!function_exists( 'welearner_after_import')):
function welearner_after_import($selected_import){
if ( 'Demo' === $selected_import['import_file_name'] ) {

  $main_menu = get_term_by('slug', 'menu-1', 'nav_menu');

      set_theme_mod( 'nav_menu_locations', array(
        'menu-1' => $main_menu->term_id,
      ));


}}
endif;




?>