<?php
/*
 * @package welearner
 * @since 1.0.0
*/
if (!class_exists('Welearner_taxonomy')){
class Welearner_taxonomy {

	private static $instance;

    function __construct() {

        //create custom post
        add_action( 'init', array( $this, 'create_taxonomy' ) );

    }

    /**
	 * getInstance();
	 * @since 1.0.0
	 * */
	public static function getInstance(){
		if (null == self::$instance){
			self::$instance = new self();
		}
		return self::$instance;
	}

    public function create_taxonomy() {

    $labels = array(
        'name'              => __( 'Course Topics', 'welearner' ),
        'singular_name'     => __( 'Course Topics', 'welearner' ),
        'search_items'      => __( 'Search Course Topics','welearner' ),
        'all_items'         => __( 'All Course Topics','welearner' ),
        'parent_item'       => __( 'Parent Course Topics','welearner' ),
        'parent_item_colon' => __( 'Parent Course Topics:', 'welearner' ),
        'edit_item'         => __( 'Edit Course Topics','welearner' ), 
        'update_item'       => __( 'Update Course Topics','welearner' ),
        'add_new_item'      => __( 'Add New Course Topics','welearner' ),
        'new_item_name'     => __( 'New Course Topics','welearner' ),
        'menu_name'         => __( 'Course Topics','welearner' ),
    );

    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
    );
    register_taxonomy( 'course-topic', 'courses', $args );



    } //end create custom post type



} // end class


 if (class_exists('Welearner_taxonomy')){
		Welearner_taxonomy::getInstance();
	}

} //endif 