<?php
/*
 * @package welearner
 * @since 1.0.0
*/

add_action('course-topic_add_form_fields', 'welearner_core_add_meta', 10, 2);
function welearner_core_add_meta($taxonomy){
    ?>
    <div class="form-field term-group">
        <label ><?php echo esc_html__( 'Upload and Image', 'welearner-core' ); ?></label>
        <input type="text" name="txt_upload_image" id="txt_upload_image"  style="width: 65%">
        <input type="button" id="upload_image_btn" class="button" value="<?php echo esc_attr__( 'Upload an Image', 'welearner-core' ); ?>" />
    </div>

    <div class="form-field term-group">
        <label ><?php echo esc_html__( 'Add Term Color', 'welearner-core' ); ?></label>
        <input type="text" class="color_field" name="wlrmetacolor" id="wlrmetacolor"  style="width: 65%">
    </div>   

    <div class="form-field term-group">
        <label ><?php echo esc_html__( 'Add Term Bg Color', 'welearner-core' ); ?></label>
        <input type="text" class="color_field" name="wlrmetabgcolor" id="wlrmetabgcolor"  style="width: 65%">
    </div>

    <?php
}

//topic categories
add_action('created_course-topic', 'save_term_image', 10, 2);

function save_term_image($term_id, $tt_id) {

    if (isset($_POST['txt_upload_image']) && '' !== $_POST['txt_upload_image']){
        $group = sanitize_url($_POST['txt_upload_image']);
        add_term_meta($term_id, 'term_image', $group, true);
    }

    if (isset($_POST['wlrmetacolor']) && '' !== $_POST['wlrmetacolor']){
        $color = sanitize_hex_color($_POST['wlrmetacolor']);
        add_term_meta($term_id, 'wlrmetacolor', $color, true);
    }   

    if (isset($_POST['wlrmetabgcolor']) && '' !== $_POST['wlrmetabgcolor']){
        $bg_color = sanitize_hex_color($_POST['wlrmetabgcolor']);
        add_term_meta($term_id, 'wlrmetabgcolor', $bg_color, true);
    }
}

//add image in edit filed
add_action('course-topic_edit_form_fields', 'welerner_taxonomy_edit_field', 10, 2);

function welerner_taxonomy_edit_field($term, $taxonomy) {
    // get current group
    $txt_upload_image = get_term_meta($term->term_id, 'term_image', true);
    //color
    $wlrmetacolor = get_term_meta($term->term_id, 'wlrmetacolor', true);

    $wlrmetabgcolor = get_term_meta($term->term_id, 'wlrmetabgcolor', true);

?>

    <tr class="form-field">
        <th><label for="taxImage"><?php _e( 'Image', 'welearner-core' ); ?></label></th>
         
        <td>     
            <input type="text" name="txt_upload_image" id="txt_upload_image" value="<?php echo $txt_upload_image ?>" >
            <input type="button" id="upload_image_btn" class="button" value="Upload an Image" />
        </td>
    </tr>  

    <tr class="form-field">
        <th><label for="taxImage"><?php _e( 'Color', 'welearner-core' ); ?></label></th>
         
        <td>     
            <input type="text" name="wlrmetacolor" class="color_field" id="wlrmetacolor" value="<?php echo $wlrmetacolor ?>" >
        </td>
    </tr>  

    <tr class="form-field">
        <th><label for="taxImage"><?php _e( 'Background Color', 'welearner-core' ); ?></label></th>
         
        <td>     
            <input type="text" name="wlrmetabgcolor" class="color_field" id="wlrmetabgcolor" value="<?php echo $wlrmetabgcolor ?>" >
        </td>
    </tr>

<?php
}



add_action('edited_course-topic', 'welerner_edit_taxonomy_field', 10, 2);
function welerner_edit_taxonomy_field($term_id, $tt_id) {
    if (isset($_POST['txt_upload_image']) && '' !== $_POST['txt_upload_image']){
        $group = sanitize_url($_POST['txt_upload_image']);
        update_term_meta($term_id, 'term_image', $group);
    }

    if (isset($_POST['wlrmetacolor']) && '' !== $_POST['wlrmetacolor']){
        $color = sanitize_hex_color($_POST['wlrmetacolor']);
        update_term_meta($term_id, 'wlrmetacolor', $color);
    }

    if (isset($_POST['wlrmetabgcolor']) && '' !== $_POST['wlrmetabgcolor']){
        $wlrmetabgcolor = sanitize_hex_color($_POST['wlrmetabgcolor']);
        update_term_meta($term_id, 'wlrmetabgcolor', $wlrmetabgcolor);
    }
}

function image_uploader_enqueue() {
    global $typenow;
    if( ($typenow == 'courses') ) {

        wp_enqueue_style( 'wp-color-picker');

        wp_enqueue_script( 'wp-color-picker');

        wp_enqueue_media();

        wp_register_script( 'meta-image', WELERNER_CORE_JS.'/media-uploader.js', array( 'jquery' ) );

        wp_localize_script( 'meta-image', 'meta_image',
            array(
                'title' => 'Upload an Image',
                'button' => 'Use this Image',
            )
        );
        wp_enqueue_script( 'meta-image' );
    }
}
add_action( 'admin_enqueue_scripts', 'image_uploader_enqueue' );