<?php
/*
 * @package welearner
 * @since 1.0.0
*/
if (!class_exists('Welearner_Cpt')){
class Welearner_Cpt {

	private static $instance;

    function __construct() {

        //create custom post
        add_action( 'init', array( $this, 'create_post_type' ) );

    }

    /**
	 * getInstance();
	 * @since 1.0.0
	 * */
	public static function getInstance(){
		if (null == self::$instance){
			self::$instance = new self();
		}
		return self::$instance;
	}

    public function create_post_type() {

        //Course post type
        
    	$Courses_labels = array(
		'name'                  => _x( 'Courses', 'Post Type General Name', 'welearner' ),
		'singular_name'         => _x( 'Course', 'Post Type Singular Name', 'welearner' ),
		'menu_name'             => __( 'Courses', 'welearner' ),
		'name_admin_bar'        => __( 'Course', 'welearner' ),
        'add_new'            => _x( 'Add New ', 'welearner'),
        'add_new_item'       => __( 'Add New ', 'welearner' ),
        'new_item'           => __( 'New course', 'welearner' ),
        'edit_item'          => __( 'Edit course', 'welearner' ),
        'view_item'          => __( 'View course', 'welearner' ),
        'all_items'          => __( 'Courses', 'welearner' ),
        'search_items'       => __( 'Search Courses', 'welearner' ),
        'parent_item_colon'  => __( 'Parent : course', 'welearner' ),
        'not_found'          => __( 'No course found.', 'welearner'),
        'not_found_in_trash' => __( 'No course found in Trash.', 'welearner' )

	);

     register_post_type( 
        'courses',
        array(
            'labels'             => $Courses_labels,
            'public'             => true,
            'supports'            =>array( 'title', 'editor','thumbnail' ),
            'hierarchical'       => false,
            'rewrite'            => array( 'slug' => 'courses' ),
            'menu_icon'          => 'dashicons-admin-generic',
            'menu_position'     => 5,
            'has_archive' => true,
        )
    );

       //Testimonial post type
        $testimonials_labels = array(
        'name'                  => _x( 'Testimonials', 'Post Type General Name', 'welearner' ),
        'singular_name'         => _x( 'Testimonial', 'Post Type Singular Name', 'welearner' ),
        'menu_name'             => __( 'Testimonials', 'welearner' ),
        'name_admin_bar'        => __( 'Testimonial', 'welearner' ),
        'add_new'            => _x( 'Add New ', 'welearner'),
        'add_new_item'       => __( 'Add New ', 'welearner' ),
        'new_item'           => __( 'New testimonial', 'welearner' ),
        'edit_item'          => __( 'Edit testimonial', 'welearner' ),
        'view_item'          => __( 'View testimonial', 'welearner' ),
        'all_items'          => __( 'Testimonials', 'welearner' ),
        'search_items'       => __( 'Search Testimonials', 'welearner' ),
        'parent_item_colon'  => __( 'Parent : testimonial', 'welearner' ),
        'not_found'          => __( 'No testimonial found.', 'welearner'),
        'not_found_in_trash' => __( 'No testimonial found in Trash.', 'welearner' )

    );

     register_post_type( 
        'testimonial',
        array(
            'labels'             => $testimonials_labels,
            'public'             => true,
            'supports'            =>array( 'title', 'editor','thumbnail' ),
            'hierarchical'       => false,
            'rewrite'            => array( 'slug' => 'testimonial' ),
            'menu_icon'          => 'dashicons-admin-generic',
            'menu_position'     => 5,
            'has_archive' => true,
        )
    );

     //Client post type
        $client_labels = array(
        'name'                  => _x( 'Client', 'Post Type General Name', 'welearner' ),
        'singular_name'         => _x( 'Client', 'Post Type Singular Name', 'welearner' ),
        'menu_name'             => __( 'Client', 'welearner' ),
        'name_admin_bar'        => __( 'Client', 'welearner' ),
        'add_new'            => _x( 'Add New ', 'welearner'),
        'add_new_item'       => __( 'Add New ', 'welearner' ),
        'new_item'           => __( 'New client', 'welearner' ),
        'edit_item'          => __( 'Edit client', 'welearner' ),
        'view_item'          => __( 'View client', 'welearner' ),
        'all_items'          => __( 'client', 'welearner' ),
        'search_items'       => __( 'Search client', 'welearner' ),
        'parent_item_colon'  => __( 'Parent : client', 'welearner' ),
        'not_found'          => __( 'No client found.', 'welearner'),
        'not_found_in_trash' => __( 'No client found in Trash.', 'welearner' )

    );

     register_post_type( 
        'client',
        array(
            'labels'             => $client_labels,
            'public'             => true,
            'supports'            =>array( 'title','thumbnail' ),
            'hierarchical'       => false,
            'rewrite'            => array( 'slug' => 'client' ),
            'menu_icon'          => 'dashicons-admin-generic',
            'menu_position'     => 5,
            'has_archive' => true,
        )
    );

     //team post type
        $testimonials_labels = array(
        'name'                  => _x( 'Team', 'Post Type General Name', 'welearner' ),
        'singular_name'         => _x( 'Team', 'Post Type Singular Name', 'welearner' ),
        'menu_name'             => __( 'Team', 'welearner' ),
        'name_admin_bar'        => __( 'Team', 'welearner' ),
        'add_new'            => _x( 'Add New ', 'welearner'),
        'add_new_item'       => __( 'Add New ', 'welearner' ),
        'new_item'           => __( 'New team', 'welearner' ),
        'edit_item'          => __( 'Edit team', 'welearner' ),
        'view_item'          => __( 'View team', 'welearner' ),
        'all_items'          => __( 'Team', 'welearner' ),
        'search_items'       => __( 'Search team', 'welearner' ),
        'parent_item_colon'  => __( 'Parent : team', 'welearner' ),
        'not_found'          => __( 'No team found.', 'welearner'),
        'not_found_in_trash' => __( 'No team found in Trash.', 'welearner' )

    );

     register_post_type( 
        'team',
        array(
            'labels'             => $testimonials_labels,
            'public'             => true,
            'supports'            =>array( 'title','thumbnail' ),
            'hierarchical'       => false,
            'rewrite'            => array( 'slug' => 'testimonial' ),
            'menu_icon'          => 'dashicons-admin-generic',
            'menu_position'     => 5,
            'has_archive' => true,
        )
    );

    //counter post type
        $counter_labels = array(
        'name'                  => _x( 'Counter', 'Post Type General Name', 'welearner' ),
        'singular_name'         => _x( 'Counter', 'Post Type Singular Name', 'welearner' ),
        'menu_name'             => __( 'Counter', 'welearner' ),
        'name_admin_bar'        => __( 'Counter', 'welearner' ),
        'add_new'            => _x( 'Add New ', 'welearner'),
        'add_new_item'       => __( 'Add New ', 'welearner' ),
        'new_item'           => __( 'New counter', 'welearner' ),
        'edit_item'          => __( 'Edit counter', 'welearner' ),
        'view_item'          => __( 'View counter', 'welearner' ),
        'all_items'          => __( 'Counter', 'welearner' ),
        'search_items'       => __( 'Search counter', 'welearner' ),
        'parent_item_colon'  => __( 'Parent : counter', 'welearner' ),
        'not_found'          => __( 'No counter found.', 'welearner'),
        'not_found_in_trash' => __( 'No counter found in Trash.', 'welearner' )

    );

     register_post_type( 
        'counter',
        array(
            'labels'             => $counter_labels,
            'public'             => true,
            'supports'            =>array( 'title' ),
            'hierarchical'       => false,
            'rewrite'            => array( 'slug' => 'counter' ),
            'menu_icon'          => 'dashicons-admin-generic',
            'menu_position'     => 5,
            'has_archive' => true,
        )
    );


    } //end create custom post type



} // end class


 if (class_exists('Welearner_Cpt')){
		Welearner_Cpt::getInstance();
	}

} //endif 